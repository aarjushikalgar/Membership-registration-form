
import './App.css';
import React, { useEffect, useState } from 'react';
import { BrowserRouter,Routes, Route } from 'react-router-dom';
//import { ToastContainer } from 'react-toastify';
//import 'react-toastify/dist/ReactToastify.css';
//import AddEdit from './pages/AddEdit';
//import View from './pages/View';
//import About from './pages/About';
//import Home from './pages/register';
//import Header from './components/Header'
import Register from './components/register';
import Listview from './components/listview';
function App() {
  useEffect(()=> {
    console.log(arr);
  })

const [arr,setArr] = useState([]);
  return (
    <div>
 {/* <Registration arr = {arr} setArr = {setArr}></Registration>
 <DisplayList arr = {arr} /> */}
 <BrowserRouter>
 <Routes>
  <Route path='/' exact element ={<Register arr = {arr} setArr = {setArr}></Register>}> 
  </Route>
  <Route path='/components/listview' exact element ={ <Listview arr = {arr} /> }></Route>
 
 </Routes>
 </BrowserRouter>
   
    </div>
  );
}

export default App;
